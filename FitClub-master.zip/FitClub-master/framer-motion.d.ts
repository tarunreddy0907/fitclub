declare module "framer-motion/dist/framer-motion" {
    export * from "framer-motion";
  }